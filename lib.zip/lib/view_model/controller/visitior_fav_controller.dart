
import 'package:elecrama/data/model/visitor_fav_model.dart';
import 'package:elecrama/data/repositories/visitor_fav_service.dart';
import 'package:get/get.dart';

class FavoriteController extends GetxController {
  final FavoriteService service = FavoriteService();

  RxBool isLoading = false.obs;

  RxList<VisitorFavoriteModel> favoriteList = <VisitorFavoriteModel>[].obs;

  /// STORE FAVORITE IDS
  RxSet<int> favoriteIds = <int>{}.obs;

  /// YOUR VISITOR ID
  int visitorId = 7669;

  @override
  void onInit() {
    super.onInit();
    getFavoriteList();
  }

  /// GET FAVORITES
  Future<void> getFavoriteList() async {
    try {
      isLoading.value = true;

      final result = await service.getFavoriteList(
        visitorId: visitorId,
      );

      favoriteList.value = result;

      favoriteIds.clear();

      for (var item in result) {
        favoriteIds.add(item.exhibitorId);
      }
    } catch (e) {
      print(e);
    } finally {
      isLoading.value = false;
    }
  }

  /// CHECK FAVORITE
  bool isFavorite(int exhibitorId) {
    return favoriteIds.contains(exhibitorId);
  }


  /// TOGGLE FAVORITE
  Future<void> toggleFavorite(int exhibitorId) async {
    try {
      final success = await service.toggleFavorite(
        exhibitorId: exhibitorId,
        visitorId: visitorId,
      );

      if (success) {
        if (favoriteIds.contains(exhibitorId)) {
          favoriteIds.remove(exhibitorId);
          favoriteList.removeWhere(
            (e) => e.exhibitorId == exhibitorId,
          );
        } else {
          favoriteIds.add(exhibitorId);

          /// REFRESH FAVORITE LIST
          await getFavoriteList();
        }

        favoriteIds.refresh();
      }
    } catch (e) {
      print(e);
    }
  }
}