import 'package:elecrama/data/model/visitormeetingmodel.dart';
import 'package:elecrama/routes/app_routes.dart';
import 'package:elecrama/view/widgets/common_appbar.dart';
import 'package:elecrama/view_model/controller/meetingController.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class VisitorMeetings extends StatefulWidget {
  const VisitorMeetings({super.key});

  @override
  State<VisitorMeetings> createState() => _VisitorMeetingsState();
}

class _VisitorMeetingsState extends State<VisitorMeetings> {
  final Meetingcontroller meetcontroller = Get.find<Meetingcontroller>();

@override
void initState() {
  super.initState();
  meetcontroller.getVisitorMeetings();
}
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: appbar,
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            child: Row(
              //mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "My Meetings",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                Spacer(),
                TextButton(
                  onPressed: () {
                    Get.toNamed(AppRoutes.exhibitorlist);
                  },
                  child: Text(
                    "Request Meetings",
                    style: TextStyle(color: Colors.blue),
                  ),
                ),
              ],
            ),
          ),

          Expanded(
            child: Obx(() {
              print(
                "Grouped Meetings = ${meetcontroller.groupedMeetings.length}",
              );

              return ListView.builder(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemCount: meetcontroller.groupedMeetings.keys.length,
                itemBuilder: (context, index) {
                  String date = meetcontroller.groupedMeetings.keys.elementAt(
                    index,
                  );

                  List<VisitorMeetingModel> meetings =
                      meetcontroller.groupedMeetings[date]!;

                  bool isExpanded = meetcontroller.expandedDate.value == date;

                  return Column(
                    children: [
                      GestureDetector(
                        onTap: () {
                          meetcontroller.toggleDate(date);
                        },

                        child: Padding(
                          padding: const EdgeInsets.all(20),

                          child: Row(
                            children: [
                              Expanded(
                                child: Text(
                                  date,
                                  style: const TextStyle(
                                    fontSize: 20,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),

                              Icon(
                                isExpanded
                                    ? Icons.keyboard_arrow_up
                                    : Icons.keyboard_arrow_down,

                                color: isExpanded ? Colors.blue : Colors.black,
                              ),
                            ],
                          ),
                        ),
                      ),

                      if (isExpanded)
                        ...meetings.map((meeting) => buildMeetingCard(meeting)),
                    ],
                  );
                },
              );
            }),
          ),
        ],
      ),
    );
  }

  Widget buildMeetingCard(VisitorMeetingModel meeting) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),

      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,

        children: [
          Text(
            meeting.txtConPerson?.trim() ?? '',
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),

          Text(meeting.txtComName ?? '', style: const TextStyle(fontSize: 18)),

          Text(
            meeting.txtConDesi ?? '',
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
          ),

          Text(meeting.meetingTime ?? ''),

          Text("Time: ${meeting.meetingTime}"),

          // const SizedBox(height: 5),

          // const Text(
          //   "Request is in Approval",
          //   style: TextStyle(
          //     color: Colors.green,
          //     fontSize: 18,
          //   ),
          // ),
          const Divider(),
        ],
      ),
    );
  }
}
