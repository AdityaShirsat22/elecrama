import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:elecrama/Api/api_constants.dart';
import 'package:elecrama/data/model/visitor_fav_model.dart';

class FavoriteService {
  final Dio _dio = Dio();

  /// GET FAVORITE LIST
  Future<List<VisitorFavoriteModel>> getFavoriteList({
    required int visitorId,
  }) async {
    try {
      final response = await _dio.get(
        ApiConstants.visitorfavlist,
        queryParameters: {
          "VisitorId": visitorId,
          "Country": "",
          "HallNo": "",
          "OrderBy": "",
        },
      );

      final data = response.data;

      List list = [];

      if (data is List) {
        list = data;
      } else if (data is String) {
        list = jsonDecode(data);
      }

      return list.map((e) => VisitorFavoriteModel.fromJson(e)).toList();
    } catch (e) {
      throw Exception("Favorite List Error : $e");
    }
  }

  /// ADD / REMOVE FAVORITE
  Future<bool> toggleFavorite({
    required int exhibitorId,
    required int visitorId,
  }) async {
    try {
      final response = await _dio.request(
        ApiConstants.visitorfavlistadddelete,
        options: Options(method: 'GET'),
        queryParameters: {"ExhibitorId": exhibitorId, "VisitorId": visitorId},
      );

      print(response.data);

      final data = response.data;

      if (data["Code"] == "1") {
        return true;
      }

      return false;
    } catch (e) {
      print("Toggle Favorite Error : $e");
      return false;
    }
  }
}
