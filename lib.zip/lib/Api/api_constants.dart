class ApiConstants {
  static const String baseurl =
      "https://elecrama25.ngauge.co.in/ElecramaService.svc";
  static const String bannerurl = "$baseurl/GetBannerList";
  static const String visitorLogin = "$baseurl/GetVisitorLogin";
  static const String exhibitorLogin = "$baseurl/getExhibitorUserLoginDetails";
  static const String otpgeneration = "$baseurl/GenerateOTPV2";
  static const String exhibitorlist = "$baseurl/SearchExhibitorNew";
  static const String visitorfavlist = "$baseurl/GetMyExhibitorList";
  static const String visitorfavlistadddelete =
      "$baseurl/SaveDeleteStarVisitorbyExhibitor";

  static const String exhibitorfavlist =
      "$baseurl/GetMyExhibitorListByExhibitor";
  static const String exhibitorfavlistadddelete =
      "$baseurl/SaveDeleteStarExhibitorbyExhibitor";

  static const String exhibitorhalllist = "$baseurl//getExhibitorHallList";
  static const String countrylist = "$baseurl/getCountryList";
  static const String subcategorylist = "$baseurl/GetsubCategoryList";

  static const String forgetvisitorpassword =
      "https://elecrama25.ngauge.co.in/Visitors/Visitor_Forgot_Password.aspx";

      static const String exhibitordates = "$baseurl/GetExhibitionDates";

      static const String visitormeetings = "$baseurl/GetVisitorMeeting";
}
